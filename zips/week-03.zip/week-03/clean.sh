#! /bin/env bash

# Remove all the generated executable files

rm 01_stdio \
   02_open \
   03_read \
   04_write \
   05_copy \
   06_lseek

# Remove all the generated txt files

rm -f *.txt
