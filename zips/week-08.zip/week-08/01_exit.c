#include <stdio.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
  printf("Exiting process...\n");
  exit(0);
}
