#! /bin/env bash

# Remove all the generated executable files

rm 01_assign \
   02_modified \
   03_abs_diff \
   04_dowhile \
   05_wwhile \
   06_ffor \
   07_array

rm -f *.s
