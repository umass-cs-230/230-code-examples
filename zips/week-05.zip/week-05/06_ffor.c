int ffor() {
    int result = 0;
    for (int i = 10; i>0; i--) {
        result = result + i;
    }
    return result;
}

int main() {
    int x = ffor();
    return 0;
}
