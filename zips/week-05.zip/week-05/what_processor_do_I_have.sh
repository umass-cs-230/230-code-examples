#! /bin/env bash

# This command tells you what processor you have:
uname -p
