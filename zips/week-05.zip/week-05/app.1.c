int main(int argc, char const *argv[]) {
    int a = 2;
    int b = 3;
    int c = a + b;
    return 0;
}
