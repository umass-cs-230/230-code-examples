#! /bin/env bash

# Remove all the generated executable files

rm 01_print_chars \
   02_print_sizes \
   03_print_sign_extension \
   04_boolean_algebra \
   05_bit_manipulations \
   06_shifting \
   07_extracting_bits_method_1 \
   08_extracting_bits_method_2
