#include <stdio.h>

int main() {
    int v = 97;
    int c = 65;

    printf("v as an integer is %i\n", v);
    printf("v as a character is %c\n", v);

    printf("c as an integer is %i\n", c);
    printf("c as a character is %c\n", c);

    return 0;
}
