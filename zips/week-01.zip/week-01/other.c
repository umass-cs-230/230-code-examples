#include <stdio.h>

void hidden() {
    int u = 'U';
    printf("%c can't see me!\n", u);
}
