#! /bin/env bash

# Remove all the generated files.
rm *.o
rm app.*
